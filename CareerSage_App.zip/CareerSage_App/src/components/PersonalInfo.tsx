import React, { useState, useEffect } from 'react'
import { useForm } from '../context/FormContext'
import type { PersonalInfo } from '../types'

export default function PersonalInfoForm({ onNext }: { onNext: () => void }) {
  const { state, setPersonal } = useForm()
  const [local, setLocal] = useState<PersonalInfo>(state.personal)

  useEffect(() => {
    setLocal(state.personal)
  }, [state.personal])

  const goNext = () => {
    if (!local.firstName || !local.email) {
      alert('Please provide at least first name and email.')
      return
    }
    setPersonal(local)
    onNext()
  }

  return (
    <div className="form-step">
      <div className="field">
        <label>First name</label>
        <input value={local.firstName} onChange={e => setLocal({...local, firstName: e.target.value})} />
      </div>
      <div className="field">
        <label>Last name</label>
        <input value={local.lastName} onChange={e => setLocal({...local, lastName: e.target.value})} />
      </div>
      <div className="field">
        <label>Email</label>
        <input type="email" value={local.email} onChange={e => setLocal({...local, email: e.target.value})} />
      </div>
      <div className="row">
        <div className="col field">
          <label>Education</label>
          <input value={local.education} onChange={e => setLocal({...local, education: e.target.value})} />
        </div>
        <div className="col field">
          <label>Years experience</label>
          <input type="number" value={local.experienceYears || 0} onChange={e => setLocal({...local, experienceYears: Number(e.target.value)})} />
        </div>
      </div>
      <div style={{display:'flex', gap:8, marginTop:12}}>
        <button onClick={goNext}>Next</button>
      </div>
    </div>
  )
}
