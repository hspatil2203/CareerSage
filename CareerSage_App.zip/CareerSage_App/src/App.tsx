import React, { useState } from 'react'
import { FormProvider } from './context/FormContext'
import PersonalInfoForm from './components/PersonalInfo'
import SkillsForm from './components/Skills'
import InterestsForm from './components/Interests'
import Review from './components/Review'
import CareerRecommendations from './components/CareerRecommendations'

const steps = ['Personal', 'Skills', 'Interests', 'Review', 'Recommendations']

export default function App() {
  const [step, setStep] = useState(0)

  return (
    <FormProvider>
      <div className="container">
        <h1>CareerSage — User Input (Phase 1)</h1>

        <div className="step-indicator">
          {steps.map((s, i) => (
            <div key={s} className="step-pill" style={{ opacity: i===step ? 1 : 0.6 }}>{s}</div>
          ))}
        </div>

        {step === 0 && <PersonalInfoForm onNext={() => setStep(1)} />}
        {step === 1 && <SkillsForm onPrev={() => setStep(0)} onNext={() => setStep(2)} />}
        {step === 2 && <InterestsForm onPrev={() => setStep(1)} onNext={() => setStep(3)} />}
        {step === 3 && <Review onPrev={() => setStep(2)} onGenerate={() => setStep(4)} />}
        {step === 4 && <CareerRecommendations onBack={() => setStep(3)} />}
      </div>
    </FormProvider>
  )
}
