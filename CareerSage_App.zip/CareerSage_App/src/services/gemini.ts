/**
 * src/services/gemini.ts
 *
 * Client-side helper: talks to your local backend proxy,
 * which handles Google Gemini API requests.
 */

type FormPayload = {
  personal: {
    firstName: string
    lastName: string
    email: string
    education?: string
    experienceYears?: number
  }
  skills: string[]
  interests: string[]
}

export type CareerRec = {
  career_title: string
  description: string
  reason: string
  confidence?: number
}

export async function getCareerRecommendations(
  form: FormPayload
): Promise<CareerRec[]> {
  const url = "http://localhost:3001/api/recommend"

  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(form),
  })

  if (!resp.ok) {
    const txt = await resp.text().catch(() => "<no body>")
    throw new Error(`Backend error: ${resp.status} ${resp.statusText} - ${txt}`)
  }

  const data = await resp.json()

  // ✅ Ensure data.recommendations exists and is an array
  const recsArray = Array.isArray(data.recommendations) ? data.recommendations : []

  // Map to your CareerRec type
  const recs: CareerRec[] = recsArray.slice(0, 3).map((r: any) => ({
    career_title: r.career_title || r.title || "Unknown",
    description: r.description || "",
    reason: r.reason || "",
    confidence: typeof r.confidence === "number" ? r.confidence : undefined,
  }))

  return recs
}
