Place backend API files here (e.g., server/index.ts or app.py). Use this folder to add server-side code that will be integrated later.
