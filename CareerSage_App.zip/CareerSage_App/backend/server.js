import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { GoogleGenerativeAI } from "@google/generative-ai";

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Initialize Gemini API client
const genAI = new GoogleGenerativeAI(process.env.VITE_GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

// Helper function to safely extract JSON from Gemini's response
function extractJSONFromResponse(result) {
  try {
    const text =
      result?.response?.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
    // Remove markdown ```json markers if present
    const cleanedText = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleanedText);

    // Ensure there is a recommendations array
    if (!parsed.recommendations || !Array.isArray(parsed.recommendations)) {
      return { recommendations: [] }; // return empty array if missing
    }
    return parsed;
  } catch (err) {
    console.error("Error parsing Gemini response:", err);
    return { recommendations: [] }; // fallback
  }
}

app.post("/api/recommend", async (req, res) => {
  try {
    const result = await model.generateContent({
      contents: [
        {
          role: "user",
          parts: [
            {
              text:
                "Provide 3 career recommendations in JSON format with a `recommendations` array, each containing `career_title`, `description`, and `reason`. User data: " +
                JSON.stringify(req.body),
            },
          ],
        },
      ],
    });

    const parsed = extractJSONFromResponse(result);

    // Send only the recommendations array to frontend
    res.json(parsed);
  } catch (err) {
    console.error("Gemini API error:", err);
    res.status(500).json({ error: err.message });
  }
});

app.listen(3001, () =>
  console.log("Server running on http://localhost:3001")
);
